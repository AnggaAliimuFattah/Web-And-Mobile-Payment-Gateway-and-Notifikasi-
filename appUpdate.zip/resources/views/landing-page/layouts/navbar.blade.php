    <header id="header" class="header d-flex align-items-center sticky-top">
        <div class="container-fluid container-xl position-relative d-flex align-items-center">

             <a href="/" class="d-flex align-items-center me-auto">
                <!-- Uncomment the line below if you also wish to use an image logo -->
                <img src="{{ asset('assets/img/branding/Logo.png') }}" width="200"  alt="">
                {{-- <h4 class=" ms-2 mt-2">YPI School</h4> --}}
            </a>

            <nav id="navmenu" class="navmenu">
               
                <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
            </nav>

       
        </div>
    </header>
